package com.ps18329;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sof3021Ps18329LeTriTamLab4Application {

	public static void main(String[] args) {
		SpringApplication.run(Sof3021Ps18329LeTriTamLab4Application.class, args);
	}

}
