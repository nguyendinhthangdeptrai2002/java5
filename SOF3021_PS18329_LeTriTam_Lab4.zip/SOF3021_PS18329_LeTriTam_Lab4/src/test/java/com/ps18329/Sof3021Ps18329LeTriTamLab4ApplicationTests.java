package com.ps18329;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sof3021Ps18329LeTriTamLab4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
