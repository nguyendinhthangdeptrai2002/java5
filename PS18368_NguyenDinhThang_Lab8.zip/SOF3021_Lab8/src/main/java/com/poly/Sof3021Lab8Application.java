package com.poly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sof3021Lab8Application {

	public static void main(String[] args) {
		SpringApplication.run(Sof3021Lab8Application.class, args);
	}

}
